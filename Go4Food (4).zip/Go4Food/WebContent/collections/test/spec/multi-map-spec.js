
module.exports = describeMultiMap;
function describeMultiMap(MultiMap, values) {
	it("should be constructable", function () {
		var accountsMultiMap = new MultiMap()
	});
};