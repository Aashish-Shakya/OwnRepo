
module.exports = (typeof WeakMap !== 'undefined') ? WeakMap : require("weak-map");
